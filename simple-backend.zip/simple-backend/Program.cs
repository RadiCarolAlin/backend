using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;


var builder = WebApplication.CreateBuilder(args);

// OIDC (Okta) din config
var okta = builder.Configuration.GetSection("Okta");

builder.Services
    .AddAuthentication(options =>
    {
        options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
        options.DefaultChallengeScheme = OpenIdConnectDefaults.AuthenticationScheme;
    })
    .AddCookie(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddOpenIdConnect(OpenIdConnectDefaults.AuthenticationScheme, options =>
    {
        options.Authority = okta["Authority"];
        options.ClientId = okta["ClientId"];
        options.ClientSecret = okta["ClientSecret"];

        options.ResponseType = "code";
        options.SaveTokens = true;                       // păstrează access/refresh în cookie
        options.GetClaimsFromUserInfoEndpoint = true;

        options.Scope.Add("openid");
        options.Scope.Add("profile");
        options.Scope.Add("email");

        // callback-uri (trebuie să corespundă celor din Okta)
        options.CallbackPath = okta["CallbackPath"];                     // /signin-oidc
        options.SignedOutCallbackPath = okta["SignedOutCallbackPath"];   // /signout-callback-oidc
    });

builder.Services.AddAuthorization();
builder.Services.AddControllers();

var app = builder.Build();

app.UseHttpsRedirection();
app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

// endpoint test neprotejat
app.MapGet("/", () => Results.Text("API up")).AllowAnonymous();

// endpoint protejat (te duce la Okta dacă nu ești logat)
app.MapGet("/secure", () => Results.Ok(new { message = "Logat prin Okta ✅" }))
   .RequireAuthorization();

// logout (te scoate și din Okta, apoi revii la /)
app.MapGet("/logout", async (HttpContext http) =>
{
    await http.SignOutAsync(OpenIdConnectDefaults.AuthenticationScheme);
    await http.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
    return Results.Redirect("/");
});

app.Run();
