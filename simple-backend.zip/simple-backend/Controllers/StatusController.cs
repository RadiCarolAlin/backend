using Microsoft.AspNetCore.Mvc;

namespace SimpleBackend.Controllers
{
    [ApiController]
    [Route("api")]
    public class StatusController : ControllerBase
    {
        [HttpGet("health")]
        public IActionResult GetHealth()
        {
            return Ok("OK");
        }

        [HttpGet("repos")]
        public IActionResult GetRepos()
        {
            var repos = new[]
            {
                new { name = "frontend", privateRepo = false },
                new { name = "backend", privateRepo = true }
            };

            return Ok(repos);
        }
    }
}
