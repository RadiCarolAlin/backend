using Microsoft.AspNetCore.Mvc;

namespace SimpleBackend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RedirectController : ControllerBase
    {
        [HttpGet] // ← fără "to-gitea"
        public IActionResult RedirectToGitea()
        {
            var giteaUrl = "http://34.116.158.79:80"; 
            return Redirect(giteaUrl);
        }
    }
}
